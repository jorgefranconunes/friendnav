d3.geo = {};

var d3_geo_radians = Math.PI / 180;
